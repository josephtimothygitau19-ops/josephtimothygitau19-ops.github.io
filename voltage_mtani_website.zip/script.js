// Simple fade-in animation on load
document.addEventListener('DOMContentLoaded', () => {
  const hero = document.querySelector('.hero-content');
  hero.style.transition = 'opacity 1.2s ease-in-out';
  setTimeout(() => {
    hero.style.opacity = 1;
  }, 200);

  console.log('Voltage Mtani site loaded successfully.');
});

// Example WhatsApp tracking placeholder
function trackWhatsAppClick() {
  console.log('WhatsApp chat link clicked!');
}
